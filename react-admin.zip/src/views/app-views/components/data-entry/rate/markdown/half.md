---
order: 1
title:
  zh-CN: 半星
  en-US: Half star
---

## zh-CN

支持选中半星。

## en-US

Support select half star.

```jsx
import { Rate } from 'antd';

ReactDOM.render(<Rate allowHalf defaultValue={2.5} />, mountNode);
```
