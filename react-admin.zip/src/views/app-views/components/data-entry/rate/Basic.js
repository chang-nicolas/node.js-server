import React, { Component } from "react";
import { Rate } from "antd";

export class Basic extends Component {
  render() {
    return <Rate />;
  }
}

export default Basic;
