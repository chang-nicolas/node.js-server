import React, { Component } from "react";
import { Input } from "antd";

export class Basic extends Component {
  render() {
    return <Input placeholder="Basic usage" />;
  }
}

export default Basic;
